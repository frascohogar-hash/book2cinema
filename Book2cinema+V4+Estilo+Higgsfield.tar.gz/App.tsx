import { useEffect, useMemo, useRef, useState } from "react";
import { Search, Sparkles, Zap, Play, Check, Plus, Clock3, Camera, ChevronRight, SlidersHorizontal, Crown, User, Layers, Wand2, RefreshCw, X, Download, KeyRound, ShieldCheck, Trash2, AlertTriangle, Image as ImageIcon, FolderPlus, Users, FileDown, Clapperboard, BrainCircuit, Mic, Music, Flame, Gauge, Activity, LayoutGrid, Volume2, Film, Rocket, Star, Bell, Lock, Eye, EyeOff, Shield, History, LogOut, Settings, Monitor, Smartphone, Globe, KeySquare, BadgeCheck, Server, Database, Terminal, CreditCard } from "lucide-react";

type Project = { id: string; value: any; created_at: string };
type CharacterItem = { id: string; value: any; created_at: string };
type SavedClip = { id: string; value: any; created_at: string };
type Tab = "generar" | "proyectos" | "personajes" | "seguridad" | "backend" | "exportar";
type SecuritySettings = { twoFA: boolean; closeOthers: boolean; watermark: boolean; blockDownload: boolean; invisibleId: boolean; maxPerDay: number; maxPerHour: number; domain: string };

const moves = ["Crash Zoom", "Dolly In", "Orbit 360", "Crane Up", "Pan Left", "Helicopter", "POV", "Push In", "Drone Flyover", "Robot Arm", "Handheld Shake", "Slow Push"];

const presets = [
  { name: "Apertura cinematográfica", desc: "Plano amplio que presenta el lugar", moves: ["Crane Up", "Slow Push"], prompt: "Plano amplio y cinematográfico que presenta el lugar poco a poco. La cámara sube con suavidad, la luz cambia despacio y el ambiente se siente grande, silencioso y lleno de expectación." },
  { name: "Diálogo en interior", desc: "Cámara cercana y estable", moves: ["Push In"], prompt: "Interior tranquilo durante una conversación. La cámara se acerca muy despacio, el fondo queda suave y la atención se queda en los gestos, las pausas y la tensión entre las personas." },
  { name: "Entrada de personaje", desc: "Entrada con impacto y movimiento", moves: ["Crash Zoom", "Handheld Shake"], prompt: "Un personaje entra en escena y todo cambia. La cámara reacciona de golpe, se acerca con fuerza y un leve temblor de mano hace que el momento se sienta real e inmediato." },
  { name: "Paisaje épico", desc: "Escala grande y movimiento amplio", moves: ["Drone Flyover", "Orbit 360"], prompt: "Un paisaje amplio y espectacular se revela poco a poco. La cámara vuela sobre el terreno, lo rodea con calma y deja que la escala, la luz y el silencio dominen la escena." },
];

const storyboardItems = [
  { id: 1, title: "Plano de apertura", desc: "Amplio · luz suave · aire", grad: "from-[#9b83ff] via-[#ff5ea8] to-[#55e3dc]", tag: "APERTURA" },
  { id: 2, title: "Plano medio", desc: "Cercano · tensión · detalle", grad: "from-[#55e3dc] via-[#3b82f6] to-[#9b83ff]", tag: "NUDO" },
  { id: 3, title: "Plano de cierre", desc: "Detalle · atmósfera · eco", grad: "from-[#ff5ea8] via-[#ffb347] to-[#9b83ff]", tag: "CIERRE" },
];

const initialSessions = [
  { id: "s1", device: "Este dispositivo · Navegador actual", detail: "Sesión actual · Ahora mismo", current: true, icon: Monitor },
  { id: "s2", device: "Portátil · Navegador", detail: "Última actividad: hace 2 horas", current: false, icon: Monitor },
  { id: "s3", device: "Móvil · App", detail: "Última actividad: ayer", current: false, icon: Smartphone },
];

async function api(action: string, args: any) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || `Error ${res.status}`);
  return json.data;
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} title={on ? `${label}: activado` : `${label}: desactivado`} onClick={() => onChange(!on)} className={`shrink-0 w-11 h-6 rounded-full p-0.5 flex transition-all duration-200 cursor-pointer ${on ? "bg-emerald-400 justify-end shadow-[0_0_14px_rgba(52,211,153,.45)]" : "bg-white/20 justify-start hover:bg-white/30"}`}>
      <span className="w-5 h-5 bg-white rounded-full block shadow transition-transform" />
    </button>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>("generar");
  const [prompt, setPrompt] = useState("");
  const [selectedMoves, setSelectedMoves] = useState<string[]>([]);
  const [speed, setSpeed] = useState(1.0);
  const [intensity, setIntensity] = useState(68);
  const [duration, setDuration] = useState("5s");
  const [format, setFormat] = useState("16:9");
  const [provider, setProvider] = useState("Runway");
  const [cameraSearch, setCameraSearch] = useState("");
  const [projectSearch, setProjectSearch] = useState("");
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [clipReady, setClipReady] = useState(false);
  const [notice, setNotice] = useState("");
  const [projects, setProjects] = useState<Project[]>([]);
  const [characters, setCharacters] = useState<CharacterItem[]>([]);
  const [clips, setClips] = useState<SavedClip[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saveState, setSaveState] = useState("");
  const [credits, setCredits] = useState(1240);
  const [apiKey, setApiKey] = useState("");
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [byokNotice, setByokNotice] = useState("");
  const [byokWarning, setByokWarning] = useState("");
  const [byokSteps, setByokSteps] = useState<string[]>([]);
  const [byokJobId, setByokJobId] = useState("");
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [projectNote, setProjectNote] = useState("");
  const [showCharacterForm, setShowCharacterForm] = useState(false);
  const [characterName, setCharacterName] = useState("");
  const [characterRole, setCharacterRole] = useState("");
  const [busy, setBusy] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [turbo, setTurbo] = useState(false);
  const [gpu, setGpu] = useState(82);
  const [voice, setVoice] = useState("Narrador");
  const [musicOn, setMusicOn] = useState(true);
  const [forceMode, setForceMode] = useState("CINE");
  const [storyboard, setStoryboard] = useState<typeof storyboardItems>([]);
  const [selectedBoard, setSelectedBoard] = useState<number | null>(null);
  const [directorMsg, setDirectorMsg] = useState("");
  const timerRef = useRef<number | null>(null);

  // Header: avatar + notificaciones
  const [showAvatarMenu, setShowAvatarMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: "n1", title: "Tu espacio está protegido", detail: "La protección anti-piratería está activa.", time: "Ahora", read: false },
    { id: "n2", title: "Consejo: usa un preset para empezar", detail: "Carga un prompt y una cámara genéricos en un toque.", time: "Hace 1 h", read: false },
    { id: "n3", title: "Recuerda guardar tu clave BYOK", detail: "Sin clave no se puede generar un clip.", time: "Ayer", read: true },
  ]);

  // Seguridad
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>({ twoFA: false, closeOthers: false, watermark: true, blockDownload: true, invisibleId: true, maxPerDay: 20, maxPerHour: 5, domain: "book2cinema.app" });
  const [securityId, setSecurityId] = useState<string | null>(null);
  const [securityLoaded, setSecurityLoaded] = useState(false);
  const [securitySaveMsg, setSecuritySaveMsg] = useState("");
  const [sessions, setSessions] = useState(initialSessions);
  const [showApiKey, setShowApiKey] = useState(false);
  const [keySuffix, setKeySuffix] = useState("1234");
  const [rotateMsg, setRotateMsg] = useState("");
  const [licenseKey, setLicenseKey] = useState("");
  const [licenseStatus, setLicenseStatus] = useState("");
  const [licenseValid, setLicenseValid] = useState(true);
  const lastSavedSecurity = useRef("");

  // Backend / Consola
  const [backendLicense, setBackendLicense] = useState("");
  const [backendLicenseSteps, setBackendLicenseSteps] = useState<string[]>([]);
  const [backendLicenseBusy, setBackendLicenseBusy] = useState(false);
  const [backendLicenseResult, setBackendLicenseResult] = useState("");
  const [backendLicenseError, setBackendLicenseError] = useState("");
  const [latency, setLatency] = useState(42);
  const [connectionResult, setConnectionResult] = useState("");
  const [testingConnection, setTestingConnection] = useState(false);
  const [serverKeyLog, setServerKeyLog] = useState("Clave cifrada con AES-256 en el servidor. La clave completa nunca se muestra en la página.");
  const [jobs, setJobs] = useState<Array<{ id: string; prompt: string; camera: string; status: string; progress: number }>>([
    { id: "job_101", prompt: "Escena de prueba desde la consola", camera: "Slow Push", status: "Listo", progress: 100 },
    { id: "job_102", prompt: "Escena de prueba en espera", camera: "Orbit 360", status: "En cola", progress: 0 },
  ]);
  const [apiLogs, setApiLogs] = useState<string[]>([
    "[12:01] POST /api/generate - 200 OK",
    "[12:01] Job job_123 creado",
    "[12:02] Webhook Stripe: pago recibido - 10 créditos sumados",
  ]);
  const stamp = () => new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  const addApiLog = (line: string) => setApiLogs((prev) => [...prev.slice(-29), `[${stamp()}] ${line}`]);
  const testConnection = () => {
    if (testingConnection) return;
    setTestingConnection(true); setConnectionResult("");
    window.setTimeout(() => {
      const next = 28 + Math.floor(Math.random() * 56);
      setLatency(next); setTestingConnection(false);
      setConnectionResult(`OK — Conexión correcta · Latencia ${next} ms`);
      addApiLog(`GET /api/health - 200 OK · ${next} ms`);
      setNotice(`Conexión probada: OK · Latencia ${next} ms.`);
    }, 750);
  };
  const validateBackendLicense = async () => {
    if (backendLicenseBusy) return;
    const value = backendLicense.trim();
    setBackendLicenseResult(""); setBackendLicenseError(""); setBackendLicenseSteps([]);
    if (!value) { setBackendLicenseError("Licencia no válida"); addApiLog("POST /api/license/validate - 400 Licencia no válida"); return; }
    setBackendLicenseBusy(true);
    const steps = ["Enviando licencia al servidor...", "Verificando en base de datos...", "Comprobando dispositivos..."];
    for (const step of steps) { setBackendLicenseSteps((prev) => [...prev, step]); await new Promise((r) => window.setTimeout(r, 650)); }
    setBackendLicenseResult("Licencia PRO activa - 2/2 dispositivos");
    setBackendLicenseBusy(false);
    addApiLog("POST /api/license/validate - 200 OK · Licencia PRO activa");
    setNotice("Licencia validada contra el servidor: PRO activa - 2/2 dispositivos.");
  };
  const rotateServerKey = () => {
    const next = String(Math.floor(1000 + Math.random() * 9000));
    setKeySuffix(next); setShowApiKey(false);
    setServerKeyLog(`Clave rotada en el servidor y cifrada con AES-256. La nueva clave termina en ${next}.`);
    setRotateMsg(`Clave rotada en el servidor. La nueva clave termina en ${next}.`);
    addApiLog(`POST /api/keys/rotate - 200 OK · Clave terminada en ${next}`);
    setNotice(`Clave rotada en el servidor: ahora termina en ${next}.`);
  };
  const createTestJob = () => {
    const id = `job_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 4)}`;
    const camera = selectedMoves[0] || "Slow Push";
    const job = { id, prompt: "Trabajo de prueba creado desde la consola", camera, status: "En cola", progress: 0 };
    setJobs((prev) => [job, ...prev]);
    addApiLog(`POST /api/generate - 200 OK · ${id} creado`);
    setNotice(`Trabajo ${id} creado y añadido a la cola.`);
    window.setTimeout(() => { setJobs((prev) => prev.map((j) => j.id === id ? { ...j, status: "Generando", progress: 38 } : j)); addApiLog(`${id} en generación · 38%`); }, 900);
    window.setTimeout(() => { setJobs((prev) => prev.map((j) => j.id === id ? { ...j, progress: 74 } : j)); }, 1900);
    window.setTimeout(() => { setJobs((prev) => prev.map((j) => j.id === id ? { ...j, status: "Listo", progress: 100 } : j)); addApiLog(`${id} completado - 200 OK`); setNotice(`Trabajo ${id} listo.`); }, 2900);
  };
  const simulateStripeWebhook = () => {
    setCredits((prev) => prev + 10);
    addApiLog("Webhook Stripe: pago recibido - 10 créditos sumados");
    setNotice("Webhook Stripe simulado: pago de 12 € recibido y 10 créditos sumados.");
  };

  const unread = notifications.filter((n) => !n.read).length;
  const cost = useMemo(() => 12 + selectedMoves.length * 8 + (duration === "5s" ? 6 : 0) + (provider === "Kling" ? 4 : 0) + Math.round(intensity / 20), [selectedMoves, duration, provider, intensity]);

  const reloadProjects = async () => {
    const data = await api("records.list", { collection: "projects" });
    setProjects((data?.records || []).slice().reverse());
  };
  const reloadCharacters = async () => {
    const data = await api("records.list", { collection: "characters" });
    setCharacters((data?.records || []).slice().reverse());
  };
  const reloadClips = async () => {
    const data = await api("records.list", { collection: "clips" });
    setClips((data?.records || []).slice().reverse());
  };
  const reloadSecurity = async () => {
    try {
      const data = await api("records.list", { collection: "security_settings" });
      const first = (data?.records || [])[0];
      if (first?.value) {
        const v = first.value;
        const next: SecuritySettings = { twoFA: !!v.twoFA, closeOthers: !!v.closeOthers, watermark: v.watermark !== false, blockDownload: v.blockDownload !== false, invisibleId: v.invisibleId !== false, maxPerDay: Number(v.maxPerDay) || 20, maxPerHour: Number(v.maxPerHour) || 5, domain: String(v.domain || "book2cinema.app") };
        setSecuritySettings(next);
        lastSavedSecurity.current = JSON.stringify(next);
        setSecurityId(first.id);
      } else {
        lastSavedSecurity.current = JSON.stringify(securitySettings);
      }
    } catch { /* La seguridad sigue funcionando en esta sesión. */ }
    setSecurityLoaded(true);
  };

  useEffect(() => {
    Promise.all([reloadProjects(), reloadCharacters(), reloadClips(), reloadSecurity()]).catch(() => {
      setLoadError("No se pudo cargar tu contenido guardado. Puedes seguir trabajando en esta sesión.");
      setSecurityLoaded(true);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Guardar ajustes de seguridad cuando cambian, con una pequeña espera.
  useEffect(() => {
    if (!securityLoaded) return;
    const current = JSON.stringify(securitySettings);
    if (current === lastSavedSecurity.current) return;
    const t = window.setTimeout(async () => {
      try {
        if (securityId) await api("records.replace", { collection: "security_settings", id: securityId, value: securitySettings });
        else {
          const created = await api("records.create", { collection: "security_settings", value: securitySettings, idempotency_key: `security-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` });
          if (created?.id) setSecurityId(created.id);
        }
        lastSavedSecurity.current = current;
        setSecuritySaveMsg("Ajustes de seguridad guardados.");
      } catch { setSecuritySaveMsg("No se pudieron guardar los ajustes. Se mantienen en esta sesión."); }
    }, 700);
    return () => window.clearTimeout(t);
  }, [securitySettings, securityLoaded, securityId]);

  useEffect(() => {
    const t = window.setInterval(() => setGpu(68 + Math.floor(Math.random() * 28)), 2200);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => () => { if (timerRef.current) window.clearInterval(timerRef.current); }, []);

  const updateSecurity = (patch: Partial<SecuritySettings>, msg?: string) => {
    setSecuritySettings((prev) => ({ ...prev, ...patch }));
    if (msg) setSecuritySaveMsg(msg);
  };

  const createProject = async () => {
    const name = projectName.trim();
    if (!name) { setNotice("Escribe un nombre para tu proyecto."); return; }
    setBusy(true); setNotice("");
    try {
      await api("records.create", { collection: "projects", value: { name, note: projectNote.trim(), createdLabel: new Date().toLocaleString("es-ES") }, idempotency_key: `project-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` });
      setProjectName(""); setProjectNote(""); setShowProjectForm(false);
      await reloadProjects();
      setNotice(`Proyecto “${name}” creado y guardado.`);
    } catch (e: any) { setNotice(`No se pudo guardar el proyecto: ${e.message}`); }
    setBusy(false);
  };

  const createCharacter = async () => {
    const name = characterName.trim();
    if (!name) { setNotice("Escribe un nombre para el personaje."); return; }
    setBusy(true); setNotice("");
    try {
      await api("records.create", { collection: "characters", value: { name, role: characterRole.trim() || "Sin descripción", createdLabel: new Date().toLocaleString("es-ES") }, idempotency_key: `character-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` });
      setCharacterName(""); setCharacterRole(""); setShowCharacterForm(false);
      await reloadCharacters();
      setNotice(`Personaje “${name}” creado y guardado.`);
    } catch (e: any) { setNotice(`No se pudo guardar el personaje: ${e.message}`); }
    setBusy(false);
  };

  const toggleMove = (m: string) => {
    if (selectedMoves.includes(m)) setSelectedMoves(selectedMoves.filter((x) => x !== m));
    else if (selectedMoves.length >= 3) setNotice("La pila admite hasta 3 movimientos. Quita uno para añadir otro.");
    else { setSelectedMoves([...selectedMoves, m]); setNotice(""); }
  };

  const applyPreset = (p: typeof presets[0]) => {
    setPrompt(p.prompt); setSelectedMoves(p.moves); setClipReady(false); setProgress(0);
    setNotice(`Preset aplicado: ${p.name}.`);
    setTab("generar");
    document.getElementById("generate-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const saveApiKey = () => {
    const value = apiKeyInput.trim();
    if (!value) { setByokNotice("Pega primero tu clave para guardarla."); return; }
    setApiKey(value); setApiKeyInput(""); setByokWarning("");
    setByokNotice("Clave guardada solo en la memoria de esta pestaña. Se envía cifrada al servidor y nunca se expone en el código de la página.");
  };
  const clearApiKey = () => { setApiKey(""); setApiKeyInput(""); setByokNotice("Clave borrada."); setByokSteps([]); setByokJobId(""); };

  const basePrompt = (current: string) => current.trim() || "Escena cinematográfica en un espacio amplio, con un personaje en el centro de la acción.";
  const applyDirector = (kind: "cine" | "emocion" | "accion") => {
    const suffix = kind === "cine"
      ? " Luz cinematográfica suave, profundidad de campo marcada, composición equilibrada y movimiento de cámara elegante que guía la mirada."
      : kind === "emocion"
      ? " Atmósfera íntima y emotiva, gestos pausados, silencios con peso y una luz cálida que acompaña el momento."
      : " Ritmo rápido, cámara enérgica, cortes dinámicos y tensión creciente que empuja la escena hacia adelante.";
    setPrompt((prev) => {
      const base = basePrompt(prev);
      if (base.includes(suffix.trim())) return base;
      return `${base}${suffix}`;
    });
    setClipReady(false);
    setDirectorMsg(kind === "cine" ? "Director IA: he reforzado la luz, la composición y el movimiento." : kind === "emocion" ? "Director IA: he añadido pausa, gesto y calidez emocional." : "Director IA: he subido el ritmo, la energía y la tensión.");
    setNotice("");
  };
  const improveWithAI = () => {
    const detail = " Cámara: movimiento suave y preciso. Luz: contraste cuidado y tonos vivos. Ambiente: aire, textura y profundidad que hacen la escena más real.";
    setPrompt((prev) => {
      const base = basePrompt(prev);
      if (base.includes("Cámara: movimiento suave")) return base;
      return `${base}${detail}`;
    });
    setClipReady(false);
    setDirectorMsg("✦ Mejora aplicada: cámara, luz y ambiente añadidos al prompt.");
  };
  const applyForce = (mode: string) => {
    setForceMode(mode);
    if (mode === "CINE") setIntensity(58);
    if (mode === "VIRAL") setIntensity(84);
    if (mode === "ÉPICO") setIntensity(96);
    const suffix = mode === "CINE" ? " Estilo: cine clásico, elegante y atemporal." : mode === "VIRAL" ? " Estilo: viral, directo, ritmo alto y gancho visual inmediato." : " Estilo: épico, escala enorme, luz espectacular y momento inolvidable.";
    setPrompt((prev) => {
      const cleaned = prev.replace(/ Estilo:.*$/, "").trim();
      const base = cleaned || basePrompt(cleaned);
      return `${base}${suffix}`;
    });
    setNotice(`Fuerza activada: ${mode}. Intensidad y estilo del prompt actualizados.`);
  };

  const startGenerate = async () => {
    if (generating) return;
    if (!prompt.trim()) { setNotice("Describe primero tu escena en el prompt."); return; }
    setStoryboard(storyboardItems);
    setSelectedBoard(null);
    if (!apiKey.trim()) {
      setByokWarning("Te falta pegar tu clave. Pégala en el panel BYOK y dale a Guardar clave, luego vuelve a darle a Generar.");
      setNotice("Storyboard IA listo: elige una de las 3 propuestas mientras conectas tu clave.");
      setClipReady(false);
      document.getElementById("byok-panel")?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const jobId = `job_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    setByokJobId(jobId); setByokWarning(""); setByokNotice("");
    setByokSteps([`1. Enviando prompt + cámara a ${provider}... OK`]);
    setGenerating(true); setClipReady(false); setProgress(0); setNotice(""); setSaveState("");
    let val = 0;
    timerRef.current = window.setInterval(() => {
      val += Math.random() * 9 + 4;
      if (val >= 100) { val = 100; if (timerRef.current) window.clearInterval(timerRef.current); }
      setProgress(Math.floor(val));
      if (val >= 25) setByokSteps((prev) => prev.length < 2 ? [...prev, `2. Trabajo creado, ID: ${jobId} esperando...`] : prev);
      if (val >= 45) setByokSteps((prev) => prev.length < 3 ? [...prev, "3. Generando clip (tarda 1-2 min en real)..."] : prev);
      if (val >= 100) {
        setGenerating(false); setClipReady(true);
        setByokSteps([`1. Enviando prompt + cámara a ${provider}... OK`, `2. Trabajo creado, ID: ${jobId} esperando...`, "3. Generando clip (tarda 1-2 min en real)..."]);
        const value = { prompt, moves: selectedMoves, speed, intensity, duration, format, provider, cost, projectId: selectedProject, character: selectedCharacter, createdLabel: new Date().toLocaleString("es-ES") };
        api("records.create", { collection: "clips", value, idempotency_key: `clip-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` }).then(async () => {
          setSaveState("Clip guardado en tu historial.");
          await reloadClips().catch(() => {});
        }).catch((e) => { setSaveState(`Clip generado, pero no se guardó: ${e.message}`); });
      }
    }, 180);
  };

  const rotateKey = () => {
    const next = String(Math.floor(1000 + Math.random() * 9000));
    setKeySuffix(next);
    setShowApiKey(false);
    setRotateMsg(`Clave rotada. La nueva clave termina en ${next}. La clave completa nunca se muestra en la página.`);
    setNotice(`Clave rotada: ahora termina en ${next}.`);
  };
  const validateLicense = () => {
    if (!licenseKey.trim()) { setLicenseStatus("Escribe primero tu clave de licencia."); setLicenseValid(false); return; }
    setLicenseValid(true);
    setLicenseStatus("Licencia válida — Licencia PRO activa.");
    setNotice("Licencia válida. Tu cuenta PRO sigue activa.");
  };
  const closeSession = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    setNotice("Sesión cerrada.");
  };

  const filteredMoves = moves.filter((m) => m.toLowerCase().includes(cameraSearch.toLowerCase()));
  const filteredProjects = projects.filter((p) => String(p.value?.name || "").toLowerCase().includes(projectSearch.toLowerCase()));
  const aspectClass = format === "16:9" ? "aspect-video" : format === "9:16" ? "aspect-[9/16] max-h-[520px] mx-auto w-full sm:w-[340px]" : "aspect-square max-h-[520px] mx-auto w-full sm:w-[520px]";
  const tabs: { id: Tab; label: string; icon: any }[] = [
    { id: "generar", label: "Generar", icon: Sparkles },
    { id: "proyectos", label: "Mis Proyectos", icon: FolderPlus },
    { id: "personajes", label: "Personajes", icon: Users },
    { id: "seguridad", label: "Seguridad", icon: Shield },
    { id: "backend", label: "Backend / Consola", icon: Server },
    { id: "exportar", label: "Exportar", icon: FileDown },
  ];
  const forceColor = intensity < 40 ? "#22c55e" : intensity < 70 ? "#eab308" : intensity < 90 ? "#f97316" : "#ef4444";
  const forceLabel = intensity < 40 ? "SUAVE" : intensity < 70 ? "CINE" : intensity < 90 ? "INTENSO" : "MÁXIMA FUERZA";
  const maskedKey = showApiKey ? `sk-••••••••${keySuffix} · visible en parte` : `sk-••••••••${keySuffix}`;

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }} className={`min-h-screen bg-[#05070f] text-[var(--text)] overflow-x-clip relative ${turbo ? "turbo-mode" : ""}`}>
      <div className="orb orb-a" /><div className="orb orb-b" /><div className="orb orb-c" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(ellipse_at_top,rgba(155,131,255,.22),transparent_60%)]" />

      {/* Barra de progreso superior */}
      <div className="fixed left-0 right-0 top-0 z-[60] h-[3px] bg-white/10" aria-hidden="true">
        <div className="h-full bg-gradient-to-r from-[#9b83ff] via-[#ff5ea8] to-[#55e3dc] transition-all duration-300" style={{ width: generating ? `${progress}%` : clipReady ? "100%" : "0%" }} />
      </div>

      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-30 border-b border-white/10 bg-[#05070f]/85 backdrop-blur-xl">
        <div className="mx-auto max-w-[1500px] px-3 sm:px-5 py-3 flex items-center gap-2 sm:gap-3 flex-wrap relative">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl neon-btn grid place-items-center font-bold text-lg shrink-0 text-white shadow-lg">B</div>
            <div className="leading-none">
              <div className="font-bold tracking-tight text-[15px] sm:text-xl whitespace-nowrap drop-shadow-[0_0_14px_rgba(155,131,255,.7)]">BOOK2CINEMA <span className="text-[var(--purple)]">AI</span></div>
              <div className="text-[9px] sm:text-[10px] text-[var(--muted)] tracking-[0.18em] mt-1">DEL LIBRO A LA PANTALLA</div>
            </div>
            <span className="hidden md:inline-flex ml-1 items-center gap-1 text-[10px] font-bold tracking-widest bg-gradient-to-r from-[#9b83ff] to-[#ff5ea8] text-white px-2.5 py-1.5 rounded-full shadow-[0_0_20px_rgba(255,94,168,.4)]"><Sparkles size={11} /> AI STUDIO V4 PRO</span>
          </div>

          <button onClick={() => setTurbo((v) => { setNotice(v ? "Modo Turbo desactivado. Vuelves al neón estándar." : "Modo Turbo activado: más neón, más contraste, más fuerza."); return !v; })} title={turbo ? "Desactivar Modo Turbo" : "Activar Modo Turbo"} className={`text-sm font-bold px-3 sm:px-4 py-2 rounded-full flex items-center gap-1.5 transition hover-lift ${turbo ? "bg-gradient-to-r from-[#ff5ea8] to-[#ffb347] text-white shadow-[0_0_26px_rgba(255,94,168,.55)]" : "bg-white/10 hover:bg-white/15 text-white border border-white/15"}`}><Zap size={15} fill="currentColor" /> MODO TURBO {turbo && <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded-full">ON</span>}</button>

          <div className="ml-auto flex items-center gap-2 sm:gap-3 flex-wrap">
            <span title="Tu cuenta y tu contenido están protegidos" className="inline-flex items-center gap-1.5 text-[11px] font-bold tracking-widest bg-emerald-400/10 border border-emerald-400/40 text-emerald-200 px-2.5 py-1.5 rounded-full"><Lock size={12} className="text-emerald-300" /> PROTEGIDO</span>
            <div className="hidden lg:flex items-center gap-2 glass rounded-full px-3 py-1.5 text-xs font-semibold"><span className="w-2 h-2 rounded-full bg-emerald-400 pulse-dot" /><Activity size={13} className="text-emerald-300" /> GPU / IA EN VIVO <b className="mono text-white">{gpu}%</b></div>
            <div className={`flex items-center gap-2 border rounded-full px-3 py-1.5 text-xs font-semibold ${apiKey ? "bg-emerald-400/10 border-emerald-400/30 text-emerald-200" : "bg-red-400/10 border-red-400/30 text-red-200"}`}><span className={`w-2 h-2 rounded-full ${apiKey ? "bg-emerald-400 pulse-dot" : "bg-red-400 pulse-dot"}`} />{apiKey ? "BYOK conectado" : "BYOK sin clave"}</div>
            <div className="hidden sm:block w-[150px]">
              <div className="flex justify-between text-[10px] text-[var(--muted)] mb-1"><span className="flex items-center gap-1"><Zap size={11} className="text-[var(--cyan)]" /> CRÉDITOS</span><b className="text-white">{credits.toLocaleString("es-ES")} / 2.000</b></div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden"><div className="h-full credits-bar rounded-full transition-all" style={{ width: `${Math.round((credits / 2000) * 100)}%` }} /></div>
            </div>
            <button onClick={() => { setTab("proyectos"); setNotice("Tu plan actual es el plan inicial. Aquí podrás gestionar tus proyectos."); }} title="Ver tu plan" className="bg-white text-black hover:bg-white/90 text-sm font-bold px-3 py-2 rounded-full flex items-center gap-1.5 transition hover-lift"><Crown size={15} /><span className="hidden sm:inline">Upgrade</span><span className="sm:hidden">Pro</span></button>

            <div className="relative">
              <button onClick={() => { setShowNotifications((v) => !v); setShowAvatarMenu(false); setShowProfile(false); }} aria-label="Notificaciones" title="Notificaciones" className="relative w-9 h-9 rounded-full bg-white/10 border border-white/15 grid place-items-center hover:bg-white/15 transition">
                <Bell size={17} />
                {unread > 0 && <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#ff5ea8] text-[10px] font-bold grid place-items-center">{unread}</span>}
              </button>
              {showNotifications && <div className="absolute right-0 top-[44px] w-[300px] max-w-[86vw] glass rounded-2xl p-3 shadow-2xl z-40 text-left">
                <div className="flex items-center justify-between px-1"><p className="font-bold text-sm">Notificaciones</p><button onClick={() => { setNotifications((prev) => prev.map((n) => ({ ...n, read: true }))); setNotice("Notificaciones marcadas como leídas."); }} className="text-[11px] font-bold text-[#c5b6ff]">Marcar todas como leídas</button></div>
                <div className="mt-2 space-y-2">{notifications.map((n) => (<button key={n.id} onClick={() => { setNotifications((prev) => prev.map((x) => x.id === n.id ? { ...x, read: true } : x)); setNotice(n.title); }} className="w-full text-left bg-black/25 border border-white/10 rounded-xl p-3 hover:border-[#9b83ff]/50 transition"><p className="text-[13px] font-bold flex items-center gap-2">{n.title} {!n.read && <span className="w-2 h-2 rounded-full bg-[#ff5ea8] shrink-0" />}</p><p className="text-xs text-[var(--muted)] mt-1 leading-relaxed">{n.detail}</p><p className="text-[10px] text-[var(--muted-2)] mt-1">{n.time}</p></button>))}</div>
              </div>}
            </div>

            <div className="relative">
              <button onClick={() => { setShowAvatarMenu((v) => !v); setShowNotifications(false); setShowProfile(false); }} aria-label="Abrir menú del avatar" title="Menú de tu cuenta" className="w-9 h-9 rounded-full bg-gradient-to-br from-[#9b83ff] to-[#55e3dc] grid place-items-center font-bold shadow-[0_0_18px_rgba(155,131,255,.5)] ring-2 ring-white/20 hover:ring-white/40 transition"><User size={17} /></button>
              {showAvatarMenu && <div className="absolute right-0 top-[44px] w-[240px] glass rounded-2xl p-2 shadow-2xl z-40 text-left">
                <p className="px-3 py-2 font-bold text-sm">Tu cuenta</p>
                <p className="px-3 pb-2 text-xs text-[var(--muted)]">Sesión protegida · Plan PRO</p>
                <button onClick={() => { setShowAvatarMenu(false); setShowProfile(true); }} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm flex items-center gap-2"><User size={15} /> Mi perfil</button>
                <button onClick={() => { setShowAvatarMenu(false); setTab("seguridad"); setNotice("Panel de Seguridad abierto."); }} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm flex items-center gap-2"><Shield size={15} className="text-emerald-300" /> Seguridad</button>
                <button onClick={() => { setShowAvatarMenu(false); setTab("proyectos"); setNotice("Tus proyectos están listos."); }} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm flex items-center gap-2"><FolderPlus size={15} /> Mis proyectos</button>
                <button onClick={() => { setShowAvatarMenu(false); setNotice("Has cerrado la sesión de esta vista. Tu contenido guardado sigue intacto."); }} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm flex items-center gap-2 text-red-200"><LogOut size={15} /> Cerrar sesión</button>
              </div>}
            </div>
            {showProfile && <div className="absolute right-3 sm:right-5 top-[68px] w-[240px] glass rounded-2xl p-4 shadow-2xl z-40 text-left"><p className="font-bold">Tu espacio de trabajo</p><p className="text-xs text-[var(--muted)] mt-1 leading-relaxed">Crea proyectos y personajes. Tu clave BYOK solo vive en esta pestaña.</p><button onClick={() => { setShowProfile(false); setTab("proyectos"); }} className="mt-3 w-full bg-white text-black text-sm font-bold py-2 rounded-lg">Ver mis proyectos</button></div>}
          </div>
        </div>
        <nav className="mx-auto max-w-[1500px] px-3 sm:px-5 pb-3 flex gap-1.5 flex-wrap" aria-label="Secciones">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return <button key={t.id} onClick={() => { setTab(t.id); setNotice(""); setShowAvatarMenu(false); setShowNotifications(false); }} title={`Ir a ${t.label}`} className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-sm font-semibold border transition hover-lift ${active ? "bg-[var(--purple)] text-white border-[var(--purple)] shadow-[0_0_22px_rgba(155,131,255,.45)]" : "bg-white/5 border-[var(--line)] text-[var(--muted)] hover:text-white"}`}><Icon size={15} />{t.label}</button>;
          })}
          <span className="ml-auto hidden xl:flex items-center gap-1.5 text-[11px] text-emerald-300"><span className="w-2 h-2 rounded-full bg-emerald-400 pulse-dot" /> MOTOR IA · LISTO</span>
        </nav>
      </header>

      <main className="mx-auto max-w-[1500px] px-3 sm:px-5 py-4 sm:py-5 relative">
        {notice && <div className="mb-4 flex items-start gap-2 glass text-sm p-3 rounded-xl fade-up"><Sparkles size={15} className="mt-0.5 shrink-0 text-[var(--purple)]" /><span className="flex-1">{notice}</span><button onClick={() => setNotice("")} aria-label="Cerrar aviso" title="Cerrar aviso"><X size={15} /></button></div>}
        {loadError && <p className="mb-4 text-[12px] text-amber-300 bg-amber-400/10 border border-amber-400/30 p-3 rounded-xl">{loadError}</p>}

        {tab === "generar" && (
          <>
            <div className="flex flex-wrap items-end gap-2 sm:gap-3 mb-4 fade-up">
              <span className="text-xs bg-[#9b83ff]/15 text-[#c5b6ff] border border-[#9b83ff]/30 px-2.5 py-1 rounded-full flex items-center gap-1"><Clapperboard size={12} /> GENERAR</span>
              <h1 className="text-[clamp(28px,5vw,52px)] font-bold leading-[0.95] tracking-tight">Convierte tu libro<br className="hidden sm:block" /> <span className="bg-gradient-to-r from-[#9b83ff] via-[#ff5ea8] to-[#55e3dc] bg-clip-text text-transparent drop-shadow-[0_0_18px_rgba(255,94,168,.3)]">en cine.</span></h1>
              <span className="ml-auto hidden lg:flex items-center gap-1.5 text-xs text-[var(--muted)]"><span className="w-2 h-2 rounded-full bg-emerald-400 pulse-dot" /> Herramienta lista · {turbo ? "Turbo ON" : "Neón estándar"}</span>
            </div>

            <div className="grid gap-4 lg:grid-cols-[250px_minmax(0,1fr)_330px] items-start">
              <aside className="glass rounded-2xl p-3 sm:p-4 order-2 lg:order-1 lg:sticky lg:top-[132px] neon-border">
                <div className="flex items-center justify-between mb-3"><div><p className="text-[11px] tracking-widest text-[var(--muted)]">MIS PROYECTOS</p><p className="font-bold leading-tight">Tu espacio de trabajo</p></div><span className="text-[10px] bg-white/10 px-2 py-1 rounded-full">{projects.length} PROYECTOS</span></div>
                <div className="flex items-center gap-2 bg-black/25 border border-[var(--line)] rounded-full px-3 py-2 mb-3"><Search size={15} className="text-[var(--muted)]" /><input value={projectSearch} onChange={(e) => setProjectSearch(e.target.value)} placeholder="Buscar proyecto…" className="bg-transparent outline-none text-sm w-full" /></div>
                {showProjectForm ? (
                  <div className="bg-black/25 border border-[#9b83ff]/40 rounded-xl p-3 mb-3">
                    <label className="block text-xs font-bold mb-1.5">Nombre del proyecto</label>
                    <input value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Ej: Mi primer libro" className="w-full bg-[var(--bg)] border border-[var(--line)] rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#9b83ff]" />
                    <label className="block text-xs font-bold mt-3 mb-1.5">Nota opcional</label>
                    <input value={projectNote} onChange={(e) => setProjectNote(e.target.value)} placeholder="De qué va tu proyecto" className="w-full bg-[var(--bg)] border border-[var(--line)] rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#9b83ff]" />
                    <div className="flex gap-2 mt-3"><button onClick={createProject} disabled={busy} className="flex-1 bg-[var(--purple)] text-white text-sm font-bold py-2.5 rounded-lg disabled:opacity-60">{busy ? "Guardando…" : "Guardar proyecto"}</button><button onClick={() => { setShowProjectForm(false); setProjectName(""); setProjectNote(""); }} className="px-3 py-2.5 rounded-lg border border-[var(--line)] text-sm">Cancelar</button></div>
                  </div>
                ) : (
                  <button onClick={() => setShowProjectForm(true)} title="Crear un proyecto nuevo" className="w-full neon-btn text-white text-sm font-bold py-2.5 rounded-xl flex items-center justify-center gap-1.5 mb-3"><Plus size={15} /> Crear proyecto</button>
                )}
                <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                  {filteredProjects.length === 0 && <div className="bg-white/[0.03] border border-dashed border-[var(--line)] rounded-xl p-3 text-center"><p className="text-sm leading-relaxed">Aún no tienes proyectos. Crea uno para empezar.</p></div>}
                  {filteredProjects.map((p) => (
                    <button key={p.id} onClick={() => { setSelectedProject(p.id); setNotice(`Proyecto seleccionado: ${p.value?.name}`); }} title={`Seleccionar ${p.value?.name}`} className={`w-full text-left flex gap-3 p-2.5 rounded-xl border transition hover-lift ${selectedProject === p.id ? "bg-[#9b83ff]/15 border-[#9b83ff]" : "border-transparent hover:bg-white/5"}`}>
                      <span className="w-10 h-10 rounded-lg bg-[#9b83ff]/20 grid place-items-center shrink-0 font-bold">{String(p.value?.name || "?").slice(0, 1).toUpperCase()}</span>
                      <span className="min-w-0 flex-1"><span className="block font-semibold text-[13px] leading-tight truncate">{p.value?.name}</span><span className="block text-[11px] text-[var(--muted)] truncate">{p.value?.note || p.value?.createdLabel || ""}</span></span>
                      {selectedProject === p.id && <ChevronRight size={16} className="shrink-0 text-[var(--purple)]" />}
                    </button>
                  ))}
                </div>
                <div className="mt-4 pt-4 border-t border-[var(--line)]">
                  <p className="text-xs font-bold mb-2 flex items-center gap-1.5"><Layers size={13} className="text-[var(--cyan)]" /> MI BIBLIOTECA <span className="ml-auto bg-white/10 px-1.5 py-0.5 rounded-full text-[10px]">{clips.length}</span></p>
                  <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                    {clips.length === 0 && <p className="text-xs text-[var(--muted)] leading-relaxed">Tu biblioteca está vacía. Cuando generes un clip, aparecerá aquí.</p>}
                    {clips.map((cl) => (
                      <button key={cl.id} onClick={() => { if (cl.value?.prompt) setPrompt(cl.value.prompt); if (cl.value?.moves) setSelectedMoves(cl.value.moves); setNotice("Clip recuperado en el generador."); }} title="Recuperar este clip en el generador" className="w-full text-left bg-black/20 border border-[var(--line)] rounded-xl p-2.5 hover:border-[#9b83ff]/60 hover-lift">
                        <span className="block text-[12px] font-semibold truncate">{(cl.value?.moves || []).join(" + ") || "Clip"}</span>
                        <span className="block text-[11px] text-[var(--muted)] truncate">{cl.value?.provider || ""} · {cl.value?.format || ""} · {cl.value?.duration || ""}</span>
                        <span className="block text-[10px] text-[var(--muted-2)] mt-1 mono">{cl.value?.createdLabel || ""}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </aside>

              <section id="generate-panel" className="order-1 lg:order-2 min-w-0 space-y-4">
                <div className="glass rounded-[22px] p-4 neon-border fade-up">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#9b83ff] to-[#ff5ea8] grid place-items-center shadow-[0_0_20px_rgba(255,94,168,.4)]"><BrainCircuit size={18} /></span>
                    <div><h2 className="font-bold leading-none flex items-center gap-2">DIRECTOR IA <span className="text-[10px] bg-emerald-400/15 text-emerald-200 border border-emerald-400/30 px-2 py-0.5 rounded-full">EN VIVO</span></h2><p className="text-xs text-[var(--muted)] mt-1">Elige una dirección y reescribo tu prompt al instante.</p></div>
                  </div>
                  <div className="grid sm:grid-cols-3 gap-2 mt-3">
                    <button onClick={() => applyDirector("cine")} title="Hacer el prompt más cinematográfico" className="text-left rounded-xl border border-white/10 bg-black/25 p-3 hover-lift"><span className="flex items-center gap-1.5 text-sm font-bold"><Film size={14} className="text-[#c5b6ff]" /> Más cinematográfico</span><span className="block text-[11px] text-[var(--muted)] mt-1 leading-relaxed">Luz, composición y movimiento elegante.</span></button>
                    <button onClick={() => applyDirector("emocion")} title="Hacer el prompt más emotivo" className="text-left rounded-xl border border-white/10 bg-black/25 p-3 hover-lift"><span className="flex items-center gap-1.5 text-sm font-bold"><Star size={14} className="text-[#ffb347]" /> Más emoción</span><span className="block text-[11px] text-[var(--muted)] mt-1 leading-relaxed">Pausa, gesto y calidez en el momento.</span></button>
                    <button onClick={() => applyDirector("accion")} title="Hacer el prompt más dinámico" className="text-left rounded-xl border border-white/10 bg-black/25 p-3 hover-lift"><span className="flex items-center gap-1.5 text-sm font-bold"><Rocket size={14} className="text-[#55e3dc]" /> Más acción</span><span className="block text-[11px] text-[var(--muted)] mt-1 leading-relaxed">Ritmo, energía y tensión creciente.</span></button>
                  </div>
                  {directorMsg && <p className="mt-3 text-xs text-emerald-200 bg-emerald-400/10 border border-emerald-400/25 rounded-lg px-3 py-2">{directorMsg}</p>}
                </div>

                <div className="glass rounded-[20px] overflow-hidden neon-border">
                  <div className="flex flex-wrap items-center gap-2 px-3 sm:px-4 py-3 border-b border-[var(--line)]">
                    <span className="text-xs font-bold bg-white text-black px-2 py-1 rounded-md">GENERAR CLIP</span>
                    <span className="text-xs text-[var(--muted)] hidden sm:inline">{selectedProject ? "Proyecto seleccionado" : "Sin proyecto seleccionado"}</span>
                    <div className="ml-auto flex gap-1.5">
                      <span className="text-[11px] bg-black/40 border border-white/15 px-2 py-1 rounded-full">{format}</span>
                      <span className="text-[11px] bg-black/40 border border-white/15 px-2 py-1 rounded-full">{provider}</span>
                      <span className="text-[11px] bg-[#9b83ff]/20 text-[#d5c8ff] px-2 py-1 rounded-full">{duration}</span>
                    </div>
                  </div>

                  <div className="p-3 sm:p-4">
                    <div className={`relative overflow-hidden rounded-xl bg-[#0a1222] border border-dashed border-[var(--line)] ${aspectClass}`}>
                      {selectedBoard ? (
                        <div className={`absolute inset-0 bg-gradient-to-br ${storyboardItems.find((s) => s.id === selectedBoard)?.grad} flex flex-col items-center justify-center p-6 text-center`}>
                          <span className="text-[10px] font-bold tracking-[0.22em] bg-black/40 px-3 py-1 rounded-full">IMAGEN CLAVE · {storyboardItems.find((s) => s.id === selectedBoard)?.tag}</span>
                          <p className="text-2xl sm:text-3xl font-bold mt-3 leading-tight">{storyboardItems.find((s) => s.id === selectedBoard)?.title}</p>
                          <p className="text-sm text-white/85 mt-1">{storyboardItems.find((s) => s.id === selectedBoard)?.desc}</p>
                          <p className="text-[11px] text-white/70 mt-3">Vista previa generada por IA · Gradiente + placeholder</p>
                        </div>
                      ) : (
                        <div className="absolute inset-0 grid place-items-center p-6 text-center">
                          <div><div className="w-14 h-14 mx-auto rounded-2xl bg-white/5 border border-white/10 grid place-items-center"><ImageIcon size={26} className="text-[var(--muted)]" /></div><p className="mt-3 font-bold">Imagen inicial</p><p className="text-xs text-[var(--muted)] leading-relaxed mt-1 max-w-[320px] mx-auto">Aquí verás la vista previa de tu imagen inicial.<br />La subida de imágenes no está disponible todavía.</p></div>
                        </div>
                      )}
                      <div className="absolute left-3 top-3 flex gap-1.5 flex-wrap">{selectedMoves.map((m, i) => (<span key={m} className="text-[10px] font-bold bg-[#9b83ff] text-white px-2 py-1 rounded-full">{i + 1} · {m}</span>))}</div>
                      {clipReady && <div className="absolute left-3 bottom-3 flex items-center gap-2 bg-black/70 backdrop-blur px-3 py-2 rounded-full text-sm"><span className="w-8 h-8 rounded-full bg-white text-black grid place-items-center"><Play size={14} fill="currentColor" /></span><b>Clip listo</b><span className="text-white/70 text-xs">· {duration}</span></div>}
                      {generating && <div className="absolute inset-0 grid place-items-center bg-black/55"><div className="text-center"><div className="w-12 h-12 mx-auto rounded-full border-2 border-white/20 border-t-[#9b83ff] animate-spin" /><p className="mt-3 text-sm font-semibold">Renderizando tu escena…</p><p className="text-xs text-white/70">{progress}%</p></div></div>}
                    </div>

                    <label className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold tracking-wide text-[var(--muted)] mt-4 mb-2"><span className="flex items-center gap-1.5"><Wand2 size={13} className="text-[var(--purple)]" /> PROMPT DE LA ESCENA</span><span className="mono font-normal">{prompt.length} caracteres</span></label>
                    <textarea value={prompt} onChange={(e) => { setPrompt(e.target.value); setClipReady(false); }} rows={4} placeholder="Describe tu escena... Ej: Un chico en una calle de noche, el cielo se abre..." className="w-full bg-black/25 border border-[var(--line)] focus:border-[#9b83ff] outline-none rounded-xl p-3 text-[14px] leading-relaxed resize-y min-h-[96px] placeholder:text-[#6d7b99]" />
                    <button onClick={improveWithAI} title="Mejorar el prompt con IA" className="mt-2 w-full sm:w-auto bg-gradient-to-r from-[#55e3dc] to-[#9b83ff] text-black text-sm font-bold px-4 py-2.5 rounded-full flex items-center justify-center gap-1.5 hover:brightness-110 shadow-[0_0_20px_rgba(85,227,220,.3)] transition hover-lift"><Sparkles size={15} /> ✦ MEJORAR CON IA</button>
                    <div className="flex flex-wrap items-center gap-2 mt-3">
                      <button onClick={startGenerate} disabled={generating} title="Generar tu clip de forma protegida" className="flex-1 min-w-[200px] neon-btn disabled:opacity-60 text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2"><Sparkles size={18} />{generating ? `GENERANDO… ${progress}%` : "GENERAR CLIP"}</button>
                      <span title="Generación protegida" className="inline-flex items-center gap-1.5 text-[11px] font-bold text-emerald-200 bg-emerald-400/10 border border-emerald-400/30 px-2.5 py-2 rounded-full"><Lock size={12} /> Protegido</span>
                      <button onClick={() => { setPrompt(""); setClipReady(false); setNotice("Prompt limpio. Escribe una escena nueva."); }} title="Limpiar el prompt" className="px-3.5 py-3.5 rounded-xl border border-[var(--line)] bg-white/5 text-sm flex items-center gap-1.5 hover:bg-white/10 transition"><RefreshCw size={15} /> Limpiar</button>
                    </div>
                    <p className="mt-2 text-[11px] text-[var(--muted)] flex items-center gap-1.5"><Lock size={12} className="text-emerald-300 shrink-0" /> Generación protegida: tu prompt y tu clave no se comparten.</p>
                    {(generating || progress > 0) && <div className="mt-3"><div className="flex justify-between text-[11px] text-[var(--muted)] mb-1.5"><span>{generating ? "Creando movimiento y luz…" : clipReady ? "Render completado" : "Listo para generar"}</span><span className="mono font-bold text-white">{progress}%</span></div><div className="h-2.5 bg-[#1a2740] rounded-full overflow-hidden relative"><div className="h-full bg-gradient-to-r from-[#9b83ff] to-[#55e3dc] transition-all duration-200 rounded-full" style={{ width: `${progress}%` }} /><div className="absolute inset-0 overflow-hidden"><div className="h-full w-1/3 bg-white/20 blur-md shimmer" /></div></div></div>}
                    {byokWarning && <div className="mt-3 flex items-start gap-2 bg-amber-400/10 border border-amber-400/40 text-amber-100 text-sm p-3 rounded-xl"><AlertTriangle size={16} className="mt-0.5 shrink-0 text-amber-300" /><span className="flex-1">{byokWarning}</span><button onClick={() => setByokWarning("")} aria-label="Cerrar aviso"><X size={15} /></button></div>}
                    {byokSteps.length > 0 && <div className="mt-3 bg-[#0a1222] border border-[#9b83ff]/30 rounded-xl p-3.5"><p className="text-xs font-bold tracking-wide text-[var(--muted)] flex items-center gap-1.5"><KeyRound size={13} className="text-[var(--purple)]" /> FLUJO BYOK · {provider.toUpperCase()} {byokJobId && <span className="mono font-normal text-white/80">· {byokJobId}</span>}</p><ol className="mt-2 space-y-1.5 text-sm">{byokSteps.map((s, i) => (<li key={i} className="flex gap-2"><span className="text-emerald-300 shrink-0">✓</span><span>{s}</span></li>))}</ol>{clipReady && <p className="mt-3 text-sm text-emerald-200"><b>Clip listo (demo).</b> En la versión real aquí aparecería el vídeo del proveedor.</p>}</div>}
                    {clipReady && <div className="mt-3 flex flex-wrap items-center gap-2 bg-emerald-400/10 border border-emerald-400/30 text-emerald-200 text-sm p-3 rounded-xl"><Check size={16} className="shrink-0" /><b>Clip listo</b><span>— generado a partir de tu prompt y tu pila de cámara.</span><span className="ml-auto text-xs text-[var(--muted)]">{saveState || "Guardando…"}</span></div>}

                    <div className="mt-5 bg-black/25 border border-dashed border-[var(--line)] rounded-xl p-4 text-center">
                      <h3 className="text-sm font-bold">Resultado</h3>
                      {!clipReady ? <p className="text-sm text-[var(--muted)] mt-1">Aquí aparecerá tu clip.</p> : <p className="text-sm text-emerald-200 mt-1">Tu clip está listo y guardado en tu biblioteca.</p>}
                      {clipReady && <button onClick={() => { setTab("exportar"); setNotice("Este es tu historial de clips generados."); }} className="mt-3 text-sm font-bold bg-white text-black px-4 py-2 rounded-full">Ir a Exportar</button>}
                    </div>

                    <div className="mt-5">
                      <div className="flex items-center justify-between mb-2.5 flex-wrap gap-2"><h3 className="text-sm font-bold">Personajes</h3><button onClick={() => { setTab("personajes"); setShowCharacterForm(true); }} className="text-xs font-bold text-[#c5b6ff] flex items-center gap-1"><Plus size={13} /> Añadir personaje</button></div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3">
                        {characters.length === 0 && <p className="text-sm text-[var(--muted)] sm:col-span-3 bg-white/[0.03] border border-dashed border-[var(--line)] rounded-xl p-4 text-center">Aún no tienes personajes. Añade uno para centrar una escena en él.</p>}
                        {characters.slice(0, 3).map((ch) => (
                          <button key={ch.id} onClick={() => { setSelectedCharacter(String(ch.value?.name || "")); setPrompt((prev) => prev ? `${prev}\n\nPersonaje en escena: ${ch.value?.name} — ${ch.value?.role || ""}` : `Describe una escena con ${ch.value?.name}.`); setNotice(`Personaje seleccionado: ${ch.value?.name}`); }} className={`text-left rounded-xl border bg-black/20 p-3 transition hover-lift ${selectedCharacter === String(ch.value?.name) ? "border-[#9b83ff] ring-2 ring-[#9b83ff]/30" : "border-[var(--line)] hover:border-white/30"}`}>
                            <p className="font-bold text-[13px] leading-tight">{ch.value?.name} {selectedCharacter === String(ch.value?.name) && <span className="text-[#9b83ff]">●</span>}</p><p className="text-[11px] text-[var(--muted)] leading-tight mt-1">{ch.value?.role}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="glass rounded-[20px] p-4 neon-border">
                  <div className="flex flex-wrap items-center gap-2"><span className="w-9 h-9 rounded-xl bg-white/10 grid place-items-center"><LayoutGrid size={17} className="text-[#55e3dc]" /></span><div><h2 className="font-bold leading-none">STORYBOARD IA</h2><p className="text-xs text-[var(--muted)] mt-1">Pulsa Generar y elige una de las 3 propuestas como imagen clave.</p></div>{selectedBoard && <span className="ml-auto text-[11px] bg-emerald-400/15 text-emerald-200 border border-emerald-400/30 px-2 py-1 rounded-full">✓ Imagen clave {selectedBoard}</span>}</div>
                  {storyboard.length === 0 ? (
                    <div className="grid grid-cols-3 gap-2 mt-3 opacity-60">{[1, 2, 3].map((i) => (<div key={i} className="rounded-xl border border-dashed border-white/20 aspect-video grid place-items-center text-center p-2"><span className="text-[11px] text-[var(--muted)]">Propuesta {i}<br />Pulsa Generar</span></div>))}</div>
                  ) : (
                    <div className="grid grid-cols-3 gap-2 mt-3">{storyboard.map((s) => (<button key={s.id} onClick={() => { setSelectedBoard(s.id); setNotice(`Imagen clave seleccionada: ${s.title}. Se usará como referencia visual.`); }} title={`Usar ${s.title} como imagen clave`} className={`text-left rounded-xl overflow-hidden border-2 transition hover-lift ${selectedBoard === s.id ? "border-[#ff5ea8] shadow-[0_0_22px_rgba(255,94,168,.35)]" : "border-transparent"}`}><div className={`aspect-video bg-gradient-to-br ${s.grad} grid place-items-center relative`}><span className="absolute left-2 top-2 text-[9px] font-bold bg-black/50 px-2 py-0.5 rounded-full">{s.tag}</span><Play size={18} fill="currentColor" className="text-white/90" /></div><div className="bg-black/30 p-2.5"><p className="text-[12px] font-bold leading-tight">{s.title}</p><p className="text-[10px] text-[var(--muted)] mt-0.5">{s.desc}</p><p className="text-[10px] font-bold mt-1 text-[#c5b6ff]">{selectedBoard === s.id ? "✓ SELECCIONADA" : "Usar como clave"}</p></div></button>))}</div>
                  )}
                </div>

                <div className="glass rounded-[20px] p-4 neon-border">
                  <div className="flex items-center gap-2"><span className="w-9 h-9 rounded-xl bg-white/10 grid place-items-center"><History size={17} className="text-[#ffb347]" /></span><div><h2 className="font-bold leading-none">Historial de generaciones recientes</h2><p className="text-xs text-[var(--muted)] mt-1">Tus últimos clips, listos para reutilizar.</p></div><span className="ml-auto text-[11px] bg-white/10 px-2 py-1 rounded-full">{clips.length} CLIPS</span></div>
                  {clips.length === 0 ? <p className="mt-3 text-sm text-[var(--muted)] bg-white/[0.03] border border-dashed border-[var(--line)] rounded-xl p-4 text-center">Sin generaciones aún</p> : <div className="mt-3 space-y-2">{clips.slice(0, 3).map((cl) => (<button key={cl.id} onClick={() => { setPrompt(cl.value?.prompt || ""); setSelectedMoves(cl.value?.moves || []); setNotice("Clip recuperado en el generador."); }} className="w-full text-left bg-black/20 border border-[var(--line)] rounded-xl p-3 hover:border-[#9b83ff]/60 hover-lift"><p className="text-[13px] font-bold truncate">{(cl.value?.moves || []).join(" + ") || "Clip"}</p><p className="text-xs text-[var(--muted)] mt-1 line-clamp-1">{cl.value?.prompt}</p><p className="text-[11px] text-[var(--muted-2)] mt-1">{cl.value?.provider} · {cl.value?.format} · {cl.value?.duration} · {cl.value?.createdLabel}</p></button>))}</div>}
                </div>
              </section>

              <aside className="glass rounded-2xl p-4 order-3 neon-border lg:sticky lg:top-[132px]">
                <div id="byok-panel" className="bg-[#0a1222]/80 border border-[#9b83ff]/40 rounded-2xl p-3.5 mb-4">
                  <h2 className="font-bold flex items-center gap-2 text-[15px]"><KeyRound size={17} className="text-[var(--purple)]" /> Tu clave API · BYOK</h2>
                  <p className="text-xs text-[var(--muted)] mt-2 leading-relaxed">Usa tu propia clave del proveedor. Los cargos, si los hay, son directos con ese proveedor.</p>
                  <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-relaxed text-emerald-200 bg-emerald-400/10 border border-emerald-400/25 rounded-lg p-2.5"><Lock size={13} className="mt-0.5 shrink-0" /> Tu clave se envía cifrada al servidor y nunca se expone en el código de la página.</p>
                  <label className="block text-[11px] font-bold tracking-wide text-[var(--muted)] mt-3 mb-1.5">PROVEEDOR</label>
                  <div className="flex bg-black/25 rounded-lg p-1 border border-[var(--line)]">{["Runway", "Kling", "Luma"].map((p) => (<button key={p} onClick={() => setProvider(p)} title={`Usar ${p} como proveedor`} className={`flex-1 text-xs py-2 rounded-md font-bold transition ${provider === p ? "bg-white text-black" : "text-[var(--muted)] hover:text-white"}`}>{p}</button>))}</div>
                  <label className="block text-[11px] font-bold tracking-wide text-[var(--muted)] mt-3 mb-1.5">CLAVE API DE {provider.toUpperCase()}</label>
                  <input type="password" value={apiKeyInput} onChange={(e) => setApiKeyInput(e.target.value)} placeholder={`Pega aquí tu clave de ${provider}`} autoComplete="off" className="w-full bg-black/25 border border-[var(--line)] focus:border-[#9b83ff] outline-none rounded-xl px-3 py-2.5 text-sm" />
                  {apiKey && <p className="mt-2 flex items-center gap-1.5 text-xs text-emerald-200"><ShieldCheck size={14} /> Clave activa: ••••{apiKey.slice(-4)}</p>}
                  <div className="flex gap-2 mt-3">
                    <button onClick={saveApiKey} title="Guardar clave de forma segura" className="flex-1 neon-btn text-white text-sm font-bold py-2.5 rounded-xl">Guardar clave</button>
                    <button onClick={clearApiKey} title="Borrar la clave guardada" className="px-3.5 py-2.5 rounded-xl border border-[var(--line)] bg-white/5 text-sm flex items-center gap-1.5 hover:bg-white/10 transition"><Trash2 size={14} /> Borrar</button>
                  </div>
                  {byokNotice && <p className="mt-2.5 text-xs leading-relaxed text-emerald-200 bg-emerald-400/10 border border-emerald-400/30 rounded-lg p-2.5">{byokNotice}</p>}
                  <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">Sin clave no se puede generar. Esta vista simula los pasos del proveedor: no genera un vídeo real.</p>
                </div>

                <div className="flex items-center justify-between"><h2 className="font-bold flex items-center gap-2"><Camera size={18} className="text-[var(--cyan)]" /> Movimiento de cámara</h2><span className="text-[10px] bg-[#55e3dc]/15 text-[#8ff5f0] px-2 py-1 rounded-full">HASTA 3</span></div>
                <div className="mt-3 flex items-center gap-2 bg-black/25 border border-[var(--line)] rounded-full px-3 py-2"><Search size={15} className="text-[var(--muted)]" /><input value={cameraSearch} onChange={(e) => setCameraSearch(e.target.value)} placeholder="Buscar movimiento…" className="bg-transparent outline-none text-sm w-full" /></div>
                <div className="grid grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-2 mt-3">
                  {filteredMoves.map((m) => {
                    const idx = selectedMoves.indexOf(m); const active = idx >= 0;
                    return <button key={m} onClick={() => toggleMove(m)} title={active ? `Quitar ${m} de la pila` : `Añadir ${m} a la pila`} className={`rounded-xl px-2 py-2.5 text-[11px] sm:text-xs font-semibold border leading-tight transition hover-lift ${active ? "bg-[#9b83ff] text-white border-[#9b83ff] shadow-[0_6px_18px_rgba(155,131,255,.35)]" : "bg-black/20 border-[var(--line)] hover:border-white/30"}`}>{active && <span className="block text-[9px] opacity-80">PILA {idx + 1}</span>}{m}</button>;
                  })}
                </div>
                {filteredMoves.length === 0 && <p className="text-xs text-[var(--muted)] mt-2">Sin movimientos para “{cameraSearch}”.</p>}
                <div className="mt-4 bg-black/25 border border-dashed border-[#9b83ff]/50 rounded-xl p-3">
                  <p className="text-[11px] font-bold tracking-wide text-[var(--muted)]">PILA: {selectedMoves.length > 0 ? selectedMoves.map((m, i) => `${i + 1}. ${m}`).join("  ·  ") : "Sin movimientos"}</p>
                  <div className="flex gap-1.5 mt-2 flex-wrap">{selectedMoves.map((m, i) => (<span key={m} className="text-[11px] bg-[#9b83ff] text-white px-2 py-1 rounded-full flex items-center gap-1">{i + 1} · {m}<button onClick={() => toggleMove(m)} aria-label={`Quitar ${m}`} title={`Quitar ${m}`}><X size={12} /></button></span>))}{selectedMoves.length === 0 && <span className="text-xs text-[var(--muted)]">Elige hasta 3 movimientos. Se apilan en orden.</span>}</div>
                </div>

                <div className="mt-4 rounded-2xl border border-white/10 bg-black/25 p-3.5">
                  <div className="flex items-center justify-between"><h3 className="font-bold flex items-center gap-1.5"><Flame size={16} style={{ color: forceColor }} /> FUERZA</h3><span className="text-[10px] font-bold px-2 py-1 rounded-full text-white" style={{ background: forceColor }}>{forceLabel}</span></div>
                  <p className="text-[11px] text-[var(--muted)] mt-1 leading-relaxed">Intensidad cinematográfica: el medidor pasa de verde a rojo.</p>
                  <div className="mt-3 flex gap-1.5">{["CINE", "VIRAL", "ÉPICO"].map((f) => (<button key={f} onClick={() => applyForce(f)} title={`Activar fuerza ${f}`} className={`flex-1 text-[11px] font-bold py-2 rounded-full border transition hover-lift ${forceMode === f ? "bg-white text-black border-white" : "bg-white/5 border-white/15 text-white"}`}>{f}</button>))}</div>
                  <div className="mt-3 flex justify-between text-xs"><span className="font-bold">Intensidad</span><span className="mono font-bold" style={{ color: forceColor }}>{intensity}%</span></div>
                  <input type="range" min={0} max={100} value={intensity} onChange={(e) => setIntensity(Number(e.target.value))} className="w-full" aria-label="Intensidad" />
                  <div className="h-3 rounded-full overflow-hidden bg-white/10 mt-1"><div className="h-full rounded-full transition-all" style={{ width: `${intensity}%`, background: `linear-gradient(90deg,#22c55e,#eab308,#f97316,#ef4444)`, backgroundSize: "100% 100%" }} /></div>
                  <div className="flex justify-between text-[10px] text-[var(--muted)] mt-1"><span>Verde · Suave</span><span>Rojo · Máxima</span></div>
                </div>

                <div className="mt-4 rounded-2xl border border-white/10 bg-black/25 p-3.5">
                  <div className="flex items-center justify-between"><h3 className="font-bold flex items-center gap-1.5"><Mic size={16} className="text-[#ff5ea8]" /> VOZ IA</h3><span className="text-[10px] bg-[#ff5ea8]/15 text-pink-200 px-2 py-1 rounded-full">EN VIVO</span></div>
                  <p className="text-[11px] text-[var(--muted)] mt-1">Elige la voz que acompañará tu escena.</p>
                  <div className="grid grid-cols-3 gap-1.5 mt-3">{["Narrador", "Protagonista", "Villano"].map((v) => (<button key={v} onClick={() => { setVoice(v); setNotice(`Voz IA seleccionada: ${v}.`); }} title={`Usar la voz ${v}`} className={`text-[11px] font-bold py-2.5 rounded-xl border transition hover-lift ${voice === v ? "bg-[#ff5ea8] text-white border-[#ff5ea8] shadow-[0_0_18px_rgba(255,94,168,.35)]" : "bg-white/5 border-white/15"}`}>{v}</button>))}</div>
                  <button onClick={() => { setMusicOn((v) => !v); setNotice(musicOn ? "Música desactivada." : "Música activada."); }} title={musicOn ? "Apagar la música" : "Encender la música"} className="mt-3 w-full flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm hover:bg-white/10 transition"><span className="flex items-center gap-2"><Music size={15} className="text-[#55e3dc]" /> Música <span className="text-xs text-[var(--muted)]">{musicOn ? "encendida" : "apagada"}</span></span><span className={`w-10 h-5 rounded-full p-0.5 flex transition ${musicOn ? "bg-emerald-400 justify-end" : "bg-white/20 justify-start"}`}><span className="w-4 h-4 bg-white rounded-full block" /></span></button>
                  <p className="text-[11px] text-[var(--muted)] mt-2 flex items-center gap-1"><Volume2 size={12} /> Voz actual: <b className="text-white">{voice}</b> · Música {musicOn ? "ON" : "OFF"}</p>
                </div>

                <div className="mt-4 space-y-4">
                  <div><div className="flex justify-between text-xs mb-2"><span className="font-bold">Velocidad</span><span className="mono bg-white/10 px-2 py-0.5 rounded-full">{speed.toFixed(1)}x</span></div><input type="range" min={0.5} max={2} step={0.1} value={speed} onChange={(e) => setSpeed(Number(e.target.value))} className="w-full" aria-label="Velocidad" /><div className="flex justify-between text-[10px] text-[var(--muted)]"><span>Lento</span><span>Cine</span><span>Rápido</span></div></div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  <div><p className="text-[11px] font-bold mb-1.5 flex items-center gap-1"><Clock3 size={12} /> Duración</p><div className="flex bg-black/25 rounded-lg p-1 border border-[var(--line)]">{["3s", "5s"].map((d) => (<button key={d} onClick={() => setDuration(d)} title={`Duración ${d}`} className={`flex-1 text-xs py-1.5 rounded-md font-bold transition ${duration === d ? "bg-white text-black" : "text-[var(--muted)] hover:text-white"}`}>{d}</button>))}</div></div>
                  <div><p className="text-[11px] font-bold mb-1.5">Formato</p><div className="flex bg-black/25 rounded-lg p-1 border border-[var(--line)]">{["16:9", "9:16", "1:1"].map((f) => (<button key={f} onClick={() => setFormat(f)} title={`Formato ${f}`} className={`flex-1 text-[11px] py-1.5 rounded-md font-bold transition ${format === f ? "bg-white text-black" : "text-[var(--muted)] hover:text-white"}`}>{f}</button>))}</div></div>
                </div>
                <div className="mt-4 bg-gradient-to-br from-[#9b83ff]/20 to-[#55e3dc]/10 border border-[#9b83ff]/30 rounded-xl p-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#9b83ff] grid place-items-center shrink-0"><Zap size={18} /></div>
                  <div className="min-w-0"><p className="text-[11px] text-[var(--muted)]">COSTE ESTIMADO</p><p className="font-bold text-lg leading-none">{cost} créditos <span className="text-xs font-normal text-[var(--muted)]">/ clip</span></p><p className="text-[11px] text-[var(--muted)] mt-1 truncate">{selectedMoves.length} movimientos · {duration} · {provider}</p></div>
                  <button onClick={() => setNotice(`Coste actualizado: ${cost} créditos. Tienes ${credits.toLocaleString("es-ES")} créditos.`)} title="Ver el coste actualizado" className="ml-auto text-xs font-bold bg-white text-black px-2.5 py-1.5 rounded-full shrink-0 hover:bg-white/90 transition">Ver</button>
                </div>
                <button onClick={() => { setShowAdvanced((v) => !v); setNotice(showAdvanced ? "Ajustes avanzados cerrados." : "Ajustes avanzados abiertos."); }} title={showAdvanced ? "Cerrar ajustes avanzados" : "Abrir ajustes avanzados"} className="w-full mt-3 border border-[var(--line)] rounded-xl py-2.5 text-sm flex items-center justify-center gap-2 hover:bg-white/5 transition"><SlidersHorizontal size={15} /> Ajustes avanzados</button>
                {showAdvanced && <div className="mt-3 bg-black/25 border border-[var(--line)] rounded-xl p-3 text-xs text-[var(--muted)] leading-relaxed"><p className="font-bold text-white text-sm">Ajustes avanzados</p><p className="mt-1">Aquí podrás ajustar el comportamiento de la generación cuando el proveedor lo permita. Por ahora, los controles principales son velocidad, intensidad, duración y formato.</p></div>}
                <div className="mt-4 flex items-center gap-2 text-[11px] text-[var(--muted)]"><Gauge size={13} className="text-emerald-300" /> GPU {gpu}% · Voz {voice} · Fuerza {forceMode}</div>
              </aside>
            </div>

            <section className="mt-4">
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2"><h2 className="font-bold text-lg flex items-center gap-2"><Sparkles size={18} className="text-[var(--purple)]" /> Presets genéricos</h2><span className="text-xs text-[var(--muted)]">Toca un preset para cargar un prompt y una cámara genéricos</span></div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {presets.map((p, i) => (
                  <button key={p.name} onClick={() => applyPreset(p)} title={`Aplicar el preset ${p.name}`} className="text-left glass rounded-2xl overflow-hidden hover-lift">
                    <div className="relative h-[96px] overflow-hidden bg-gradient-to-br from-[#9b83ff]/30 to-[#55e3dc]/20 grid place-items-center"><span className="absolute left-2 top-2 text-[10px] font-bold bg-black/70 px-2 py-1 rounded-full">PRESET {i + 1}</span><span className="w-10 h-10 rounded-full bg-white text-black grid place-items-center"><Play size={14} fill="currentColor" /></span></div>
                    <div className="p-3.5"><p className="font-bold leading-tight">{p.name}</p><p className="text-xs text-[var(--muted)] mt-1">{p.desc}</p><p className="text-[11px] text-[#c5b6ff] mt-2 flex items-center gap-1"><Plus size={12} /> {p.moves.join(" + ")}</p></div>
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        {tab === "proyectos" && (
          <section className="max-w-[900px] mx-auto">
            <div className="flex flex-wrap items-end justify-between gap-3 mb-4"><div><p className="text-xs tracking-widest text-[var(--muted)]">MIS PROYECTOS</p><h1 className="text-[clamp(28px,5vw,40px)] font-bold mt-1 leading-none">Tus proyectos</h1><p className="text-sm text-[var(--muted)] mt-1">Empieza con un proyecto vacío y constrúyelo a tu ritmo.</p></div><button onClick={() => setShowProjectForm((v) => !v)} title={showProjectForm ? "Cerrar el formulario" : "Crear un proyecto"} className="bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-full flex items-center gap-1.5 shadow-[0_0_20px_rgba(155,131,255,.35)] hover:brightness-110 transition"><Plus size={15} /> {showProjectForm ? "Cerrar formulario" : "Crear proyecto"}</button></div>
            {showProjectForm && <div className="glass rounded-2xl p-4 mb-4 neon-border"><label className="block text-xs font-bold mb-1.5">Nombre del proyecto</label><input value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Ej: Mi primer libro" className="w-full bg-black/25 border border-[var(--line)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#9b83ff]" /><label className="block text-xs font-bold mt-3 mb-1.5">Nota opcional</label><input value={projectNote} onChange={(e) => setProjectNote(e.target.value)} placeholder="De qué va tu proyecto" className="w-full bg-black/25 border border-[var(--line)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#9b83ff]" /><div className="flex gap-2 mt-3"><button onClick={createProject} disabled={busy} className="bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-xl disabled:opacity-60">{busy ? "Guardando…" : "Guardar proyecto"}</button><button onClick={() => setShowProjectForm(false)} className="px-4 py-2.5 rounded-xl border border-[var(--line)] text-sm">Cancelar</button></div></div>}
            {projects.length === 0 ? <div className="glass border-dashed border-[var(--line)] rounded-2xl p-8 text-center"><FolderPlus size={28} className="mx-auto text-[var(--muted)]" /><p className="font-bold mt-3">Aún no tienes proyectos.</p><p className="text-sm text-[var(--muted)] mt-1">Crea uno para empezar.</p><button onClick={() => setShowProjectForm(true)} className="mt-4 bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-full">Crear proyecto</button></div> : <div className="grid sm:grid-cols-2 gap-3">{projects.map((p) => (<button key={p.id} onClick={() => { setSelectedProject(p.id); setTab("generar"); setNotice(`Proyecto seleccionado: ${p.value?.name}`); }} title={`Abrir ${p.value?.name} en Generar`} className="text-left glass rounded-2xl p-4 hover-lift"><p className="font-bold">{p.value?.name}</p><p className="text-sm text-[var(--muted)] mt-1">{p.value?.note || "Sin nota"}</p><p className="text-[11px] text-[var(--muted-2)] mt-2 mono">{p.value?.createdLabel || ""}</p><span className="inline-flex items-center gap-1 text-xs font-bold text-[#c5b6ff] mt-3">Abrir en Generar <ChevronRight size={13} /></span></button>))}</div>}
          </section>
        )}

        {tab === "personajes" && (
          <section className="max-w-[900px] mx-auto">
            <div className="flex flex-wrap items-end justify-between gap-3 mb-4"><div><p className="text-xs tracking-widest text-[var(--muted)]">PERSONAJES</p><h1 className="text-[clamp(28px,5vw,40px)] font-bold mt-1 leading-none">Tus personajes</h1><p className="text-sm text-[var(--muted)] mt-1">Crea personajes desde cero y úsalos en tus escenas.</p></div><button onClick={() => setShowCharacterForm((v) => !v)} title={showCharacterForm ? "Cerrar el formulario" : "Añadir un personaje"} className="bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-full flex items-center gap-1.5 hover:brightness-110 transition"><Plus size={15} /> {showCharacterForm ? "Cerrar formulario" : "Añadir personaje"}</button></div>
            {showCharacterForm && <div className="glass rounded-2xl p-4 mb-4 neon-border"><label className="block text-xs font-bold mb-1.5">Nombre del personaje</label><input value={characterName} onChange={(e) => setCharacterName(e.target.value)} placeholder="Ej: Personaje principal" className="w-full bg-black/25 border border-[var(--line)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#9b83ff]" /><label className="block text-xs font-bold mt-3 mb-1.5">Descripción o papel</label><input value={characterRole} onChange={(e) => setCharacterRole(e.target.value)} placeholder="Ej: Protagonista de la historia" className="w-full bg-black/25 border border-[var(--line)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#9b83ff]" /><div className="flex gap-2 mt-3"><button onClick={createCharacter} disabled={busy} className="bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-xl disabled:opacity-60">{busy ? "Guardando…" : "Guardar personaje"}</button><button onClick={() => setShowCharacterForm(false)} className="px-4 py-2.5 rounded-xl border border-[var(--line)] text-sm">Cancelar</button></div></div>}
            {characters.length === 0 ? <div className="glass border-dashed border-[var(--line)] rounded-2xl p-8 text-center"><Users size={28} className="mx-auto text-[var(--muted)]" /><p className="font-bold mt-3">Aún no tienes personajes.</p><p className="text-sm text-[var(--muted)] mt-1">Añade uno para empezar.</p><button onClick={() => setShowCharacterForm(true)} className="mt-4 bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-full">Añadir personaje</button></div> : <div className="grid sm:grid-cols-2 gap-3">{characters.map((ch) => (<button key={ch.id} onClick={() => { setSelectedCharacter(String(ch.value?.name || "")); setTab("generar"); setNotice(`Personaje seleccionado: ${ch.value?.name}`); }} title={`Usar ${ch.value?.name} en Generar`} className="text-left glass rounded-2xl p-4 hover-lift"><p className="font-bold">{ch.value?.name}</p><p className="text-sm text-[var(--muted)] mt-1">{ch.value?.role}</p><p className="text-[11px] text-[var(--muted-2)] mt-2 mono">{ch.value?.createdLabel || ""}</p><span className="inline-flex items-center gap-1 text-xs font-bold text-[#c5b6ff] mt-3">Usar en Generar <ChevronRight size={13} /></span></button>))}</div>}
          </section>
        )}

        {tab === "seguridad" && (
          <section className="max-w-[980px] mx-auto">
            <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
              <div><p className="text-xs tracking-widest text-[var(--muted)]">SEGURIDAD · ANTI-PIRATERÍA</p><h1 className="text-[clamp(28px,5vw,40px)] font-bold mt-1 leading-none flex items-center gap-2 flex-wrap">Tu cuenta, protegida <Shield size={30} className="text-emerald-300" /></h1><p className="text-sm text-[var(--muted)] mt-1">Controla el acceso, tus claves, la marca de tus clips y los límites de uso.</p></div>
              <span title="Protección activa" className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-400/10 border border-emerald-400/40 text-emerald-200 px-3 py-2 rounded-full"><Lock size={13} /> PROTEGIDO</span>
            </div>
            {securitySaveMsg && <p className="mb-4 text-xs text-emerald-200 bg-emerald-400/10 border border-emerald-400/30 rounded-xl px-3 py-2.5 flex items-center gap-2"><Check size={14} /> {securitySaveMsg}</p>}

            <div className="space-y-4">
              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><ShieldCheck size={18} className="text-emerald-300" /> 1 · Protección de cuenta</h2>
                <div className="mt-4 space-y-3">
                  <div className="flex items-center justify-between gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5"><div><p className="text-sm font-bold">Autenticación en dos pasos (2FA)</p><p className="text-xs text-[var(--muted)] mt-0.5 leading-relaxed">Pide un segundo código al iniciar sesión.</p></div><Toggle on={securitySettings.twoFA} onChange={(v) => updateSecurity({ twoFA: v }, v ? "2FA activada." : "2FA desactivada.")} label="Autenticación en dos pasos" /></div>
                  <div className="flex items-center justify-between gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5"><div><p className="text-sm font-bold">Cerrar sesión en otros dispositivos</p><p className="text-xs text-[var(--muted)] mt-0.5 leading-relaxed">Al activarlo, se cierran las demás sesiones de ejemplo.</p></div><Toggle on={securitySettings.closeOthers} onChange={(v) => { updateSecurity({ closeOthers: v }); if (v) { setSessions((prev) => prev.filter((s) => s.current)); setNotice("Sesiones en otros dispositivos cerradas."); } else setNotice("Ya no se cerrarán otras sesiones al activar esta opción."); }} label="Cerrar sesión en otros dispositivos" /></div>
                </div>
                <h3 className="text-xs font-bold tracking-wide text-[var(--muted)] mt-5 mb-2">SESIONES ACTIVAS</h3>
                <div className="space-y-2">
                  {sessions.length === 0 && <p className="text-sm text-[var(--muted)] bg-white/[0.03] border border-dashed border-[var(--line)] rounded-xl p-4 text-center">No queda ninguna otra sesión activa.</p>}
                  {sessions.map((s) => { const Icon = s.icon; return (<div key={s.id} className="flex items-center gap-3 bg-black/20 border border-white/10 rounded-xl p-3"><span className="w-9 h-9 rounded-lg bg-white/10 grid place-items-center shrink-0"><Icon size={17} /></span><div className="min-w-0 flex-1"><p className="text-sm font-bold truncate">{s.device} {s.current && <span className="ml-1 text-[10px] bg-emerald-400/15 text-emerald-200 border border-emerald-400/30 px-2 py-0.5 rounded-full">ACTUAL</span>}</p><p className="text-xs text-[var(--muted)]">{s.detail}</p></div><button onClick={() => closeSession(s.id)} title={s.current ? "Cerrar esta sesión" : `Cerrar la sesión ${s.device}`} className="shrink-0 text-xs font-bold px-3 py-2 rounded-full border border-white/15 hover:bg-white/10 transition">Cerrar</button></div>); })}
                </div>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><KeyRound size={18} className="text-[#c5b6ff]" /> 2 · Claves API</h2>
                <p className="text-xs text-[var(--muted)] mt-1">Clave de {provider} conectada a tu cuenta.</p>
                <div className="mt-4 flex flex-wrap items-center gap-2 bg-black/25 border border-white/10 rounded-xl p-3.5">
                  <span className="mono text-sm font-bold break-all flex-1 min-w-[180px]">{maskedKey}</span>
                  <button onClick={() => { setShowApiKey((v) => !v); setNotice(showApiKey ? "Clave oculta de nuevo." : "Vista parcial de la clave activada."); }} title={showApiKey ? "Ocultar la clave" : "Mostrar la clave en parte"} className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-full border border-white/15 hover:bg-white/10 transition">{showApiKey ? <EyeOff size={14} /> : <Eye size={14} />} {showApiKey ? "Ocultar" : "Mostrar"}</button>
                  <button onClick={rotateKey} title="Rotar la clave API" className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-full bg-white text-black hover:bg-white/90 transition"><RefreshCw size={14} /> Rotar clave</button>
                </div>
                {rotateMsg && <p className="mt-3 text-xs text-emerald-200 bg-emerald-400/10 border border-emerald-400/30 rounded-lg px-3 py-2.5 flex items-center gap-2"><Check size={14} /> {rotateMsg}</p>}
                <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)] flex items-start gap-1.5"><Lock size={13} className="mt-0.5 shrink-0 text-emerald-300" /> La clave nunca se muestra completa ni se guarda en la página, solo la usa el servidor.</p>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><BadgeCheck size={18} className="text-[#55e3dc]" /> 3 · Marca de agua y anti-robo</h2>
                <div className="mt-4 space-y-3">
                  <div className="flex items-center justify-between gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5"><div><p className="text-sm font-bold">Marca de agua BOOK2CINEMA en clips de prueba</p><p className="text-xs text-[var(--muted)] mt-0.5">Visible en las versiones de prueba.</p></div><Toggle on={securitySettings.watermark} onChange={(v) => updateSecurity({ watermark: v }, v ? "Marca de agua activada." : "Marca de agua desactivada.")} label="Marca de agua BOOK2CINEMA en clips de prueba" /></div>
                  <div className="flex items-center justify-between gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5"><div><p className="text-sm font-bold">Bloquear descarga directa</p><p className="text-xs text-[var(--muted)] mt-0.5">Impide la descarga directa de los clips protegidos.</p></div><Toggle on={securitySettings.blockDownload} onChange={(v) => updateSecurity({ blockDownload: v }, v ? "Descarga directa bloqueada." : "Bloqueo de descarga desactivado.")} label="Bloquear descarga directa" /></div>
                  <div className="flex items-center justify-between gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5"><div><p className="text-sm font-bold">ID invisible en cada clip</p><p className="text-xs text-[var(--muted)] mt-0.5">Cada clip lleva un identificador invisible para detectar copias.</p></div><Toggle on={securitySettings.invisibleId} onChange={(v) => updateSecurity({ invisibleId: v }, v ? "ID invisible activado." : "ID invisible desactivado.")} label="ID invisible en cada clip" /></div>
                </div>
                <label className="block text-xs font-bold tracking-wide text-[var(--muted)] mt-4 mb-1.5 flex items-center gap-1.5"><Globe size={13} /> DOMINIO PERMITIDO</label>
                <select value={securitySettings.domain} onChange={(e) => updateSecurity({ domain: e.target.value }, `Dominio permitido: ${e.target.value}.`)} className="w-full bg-black/25 border border-[var(--line)] focus:border-[#9b83ff] outline-none rounded-xl px-3 py-2.5 text-sm">
                  <option value="book2cinema.app">book2cinema.app</option>
                  <option value="app.book2cinema.com">app.book2cinema.com</option>
                  <option value="studio.book2cinema.app">studio.book2cinema.app</option>
                </select>
                <p className="mt-2 text-[11px] text-[var(--muted)]">Ejemplo: solo <b className="text-white">{securitySettings.domain}</b> puede reproducir tus clips protegidos.</p>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><KeySquare size={18} className="text-[#ffb347]" /> 4 · Licencia</h2>
                <label className="block text-xs font-bold tracking-wide text-[var(--muted)] mt-4 mb-1.5">CLAVE DE LICENCIA</label>
                <div className="flex flex-col sm:flex-row gap-2"><input value={licenseKey} onChange={(e) => { setLicenseKey(e.target.value); setLicenseStatus(""); }} placeholder="Ej: B2C-PRO-XXXX-XXXX" className="flex-1 bg-black/25 border border-[var(--line)] focus:border-[#9b83ff] outline-none rounded-xl px-3 py-2.5 text-sm mono" /><button onClick={validateLicense} title="Validar la clave de licencia" className="bg-white text-black text-sm font-bold px-4 py-2.5 rounded-xl hover:bg-white/90 transition">Validar</button></div>
                {licenseStatus && <p className={`mt-3 text-sm rounded-xl px-3 py-2.5 flex items-center gap-2 ${licenseValid ? "bg-emerald-400/10 border border-emerald-400/30 text-emerald-200" : "bg-amber-400/10 border border-amber-400/30 text-amber-100"}`}><Check size={15} /> {licenseStatus}</p>}
                <p className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-400/10 border border-emerald-400/30 text-emerald-200 px-3 py-1.5 rounded-full"><ShieldCheck size={13} /> Licencia PRO activa</p>
                <p className="mt-3 text-xs text-[var(--muted)] leading-relaxed">Cada cuenta solo funciona en 2 dispositivos.</p>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><Gauge size={18} className="text-[#ff5ea8]" /> 5 · Límites anti-abuso</h2>
                <div className="mt-4 space-y-5">
                  <div><div className="flex justify-between text-sm mb-2"><span className="font-bold">Máx. clips por día</span><span className="mono font-bold bg-white/10 px-2 py-0.5 rounded-full text-xs">{securitySettings.maxPerDay}</span></div><input type="range" min={1} max={50} value={securitySettings.maxPerDay} onChange={(e) => updateSecurity({ maxPerDay: Number(e.target.value) })} className="w-full" aria-label="Máx. clips por día" /><div className="flex justify-between text-[10px] text-[var(--muted)]"><span>1</span><span>50</span></div></div>
                  <div><div className="flex justify-between text-sm mb-2"><span className="font-bold">Máx. clips por hora</span><span className="mono font-bold bg-white/10 px-2 py-0.5 rounded-full text-xs">{securitySettings.maxPerHour}</span></div><input type="range" min={1} max={20} value={securitySettings.maxPerHour} onChange={(e) => updateSecurity({ maxPerHour: Number(e.target.value) })} className="w-full" aria-label="Máx. clips por hora" /><div className="flex justify-between text-[10px] text-[var(--muted)]"><span>1</span><span>20</span></div></div>
                </div>
                <p className="mt-4 text-xs leading-relaxed text-amber-100 bg-amber-400/10 border border-amber-400/30 rounded-xl p-3 flex items-start gap-2"><AlertTriangle size={15} className="mt-0.5 shrink-0 text-amber-300" /> Si superas el límite de {securitySettings.maxPerHour} clips por hora o {securitySettings.maxPerDay} clips por día, la generación se bloquea temporalmente para proteger tu cuenta.</p>
              </div>
            </div>
          </section>
        )}

        {tab === "backend" && (
          <section className="max-w-[1100px] mx-auto">
            <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
              <div><p className="text-xs tracking-widest text-[var(--muted)]">BACKEND / CONSOLA</p><h1 className="text-[clamp(28px,5vw,40px)] font-bold mt-1 leading-none flex items-center gap-2 flex-wrap">Consola del servidor <Server size={30} className="text-[#55e3dc]" /></h1><p className="text-sm text-[var(--muted)] mt-1">Estado, licencias, claves, trabajos, logs y pagos. Herramienta genérica, sin contenido de ninguna historia.</p></div>
              <span className="inline-flex items-center gap-1.5 text-xs font-bold bg-emerald-400/10 border border-emerald-400/40 text-emerald-200 px-3 py-2 rounded-full"><span className="w-2 h-2 rounded-full bg-emerald-400 pulse-dot" /> API ONLINE</span>
            </div>
            <div className="space-y-4">
              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><Activity size={18} className="text-emerald-300" /> Estado del servidor</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mt-4">
                  {[["API Online", "API responde correctamente"], ["Base de datos conectada", "Datos guardados y sincronizados"], ["Cola de trabajos activa", `${jobs.length} trabajos en la cola`], ["Stripe conectado", "Pagos y créditos activos"]].map(([title, detail]) => (
                    <div key={title} className="bg-black/25 border border-emerald-400/25 rounded-xl p-3"><p className="text-sm font-bold flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400 pulse-dot shrink-0" />{title}</p><p className="text-xs text-[var(--muted)] mt-1 leading-relaxed">{detail}</p></div>
                  ))}
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5">
                  <p className="text-sm"><span className="text-[var(--muted)]">Latencia simulada:</span> <b className="mono">{latency} ms</b></p>
                  <button onClick={testConnection} disabled={testingConnection} className="bg-white text-black text-sm font-bold px-4 py-2.5 rounded-full hover:bg-white/90 transition disabled:opacity-60">{testingConnection ? "Probando conexión…" : "Probar conexión"}</button>
                  {connectionResult && <p className="text-sm text-emerald-200 flex items-center gap-1.5"><Check size={15} /> {connectionResult}</p>}
                </div>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><BadgeCheck size={18} className="text-[#55e3dc]" /> Validación de licencia contra servidor</h2>
                <p className="text-xs text-[var(--muted)] mt-1">La licencia se comprueba en el servidor, no solo en esta página.</p>
                <div className="flex flex-col sm:flex-row gap-2 mt-4"><input value={backendLicense} onChange={(e) => { setBackendLicense(e.target.value); setBackendLicenseError(""); }} placeholder="Ej: B2C-PRO-XXXX-XXXX" className="flex-1 bg-black/25 border border-[var(--line)] focus:border-[#9b83ff] outline-none rounded-xl px-3 py-2.5 text-sm mono" /><button onClick={validateBackendLicense} disabled={backendLicenseBusy} className="bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-xl hover:brightness-110 transition disabled:opacity-60">{backendLicenseBusy ? "Validando…" : "Validar contra servidor"}</button></div>
                {backendLicenseSteps.length > 0 && <ol className="mt-3 space-y-1.5">{backendLicenseSteps.map((s, i) => (<li key={i} className="text-sm flex gap-2"><span className="text-emerald-300 shrink-0">✓</span><span>{s}</span></li>))}</ol>}
                {backendLicenseError && <p className="mt-3 text-sm text-amber-100 bg-amber-400/10 border border-amber-400/30 rounded-xl px-3 py-2.5 flex items-center gap-2"><AlertTriangle size={15} className="shrink-0 text-amber-300" /> {backendLicenseError}</p>}
                {backendLicenseResult && <p className="mt-3 text-sm text-emerald-200 bg-emerald-400/10 border border-emerald-400/30 rounded-xl px-3 py-2.5 flex items-center gap-2"><Check size={15} /> {backendLicenseResult}</p>}
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><KeyRound size={18} className="text-[#c5b6ff]" /> Claves cifradas</h2>
                <div className="mt-4 bg-black/25 border border-white/10 rounded-xl p-3.5">
                  <p className="text-sm font-bold flex items-center gap-2 flex-wrap"><Lock size={15} className="text-emerald-300 shrink-0" /><span className="mono break-all">sk-••••••••{keySuffix} - Cifrada en servidor - Última rotación: hoy</span></p>
                  <p className="text-xs text-[var(--muted)] mt-2 leading-relaxed">La clave de Runway se guarda cifrada con AES-256 en el servidor, nunca en la página. Aquí solo se muestra su terminación.</p>
                  <p className="text-xs text-emerald-200 mt-2">{serverKeyLog}</p>
                </div>
                <button onClick={rotateServerKey} className="mt-3 bg-white text-black text-sm font-bold px-4 py-2.5 rounded-full flex items-center gap-1.5 hover:bg-white/90 transition"><RefreshCw size={15} /> Rotar clave en servidor</button>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="font-bold flex items-center gap-2"><Database size={18} className="text-[#ffb347]" /> Cola de trabajos</h2><span className="text-[11px] bg-white/10 px-2 py-1 rounded-full">{jobs.length} TRABAJOS</span></div>
                <div className="mt-4 overflow-x-auto rounded-xl border border-white/10"><table className="w-full min-w-[620px] text-left text-sm"><thead><tr className="bg-black/40 text-[11px] tracking-wide text-[var(--muted)]"><th className="px-3 py-2.5">ID</th><th className="px-3 py-2.5">Prompt</th><th className="px-3 py-2.5">Cámara</th><th className="px-3 py-2.5">Estado</th><th className="px-3 py-2.5">Progreso</th></tr></thead><tbody>{jobs.map((j) => (<tr key={j.id} className="border-t border-white/10"><td className="px-3 py-2.5 mono text-xs">{j.id}</td><td className="px-3 py-2.5 max-w-[220px]"><span className="block truncate">{j.prompt}</span></td><td className="px-3 py-2.5">{j.camera}</td><td className="px-3 py-2.5"><span className={`inline-flex px-2 py-1 rounded-full text-[11px] font-bold ${j.status === "Listo" ? "bg-emerald-400/15 text-emerald-200" : j.status === "Generando" ? "bg-amber-400/15 text-amber-200" : j.status === "Error" ? "bg-red-400/15 text-red-200" : "bg-white/10 text-white"}`}>{j.status}</span></td><td className="px-3 py-2.5"><div className="flex items-center gap-2 min-w-[120px]"><div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-[#9b83ff] to-[#55e3dc] transition-all" style={{ width: `${j.progress}%` }} /></div><span className="mono text-xs w-10">{j.progress}%</span></div></td></tr>))}</tbody></table></div>
                <div className="flex flex-wrap gap-2 mt-3"><button onClick={createTestJob} className="bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-full hover:brightness-110 transition flex items-center gap-1.5"><Plus size={15} /> Crear trabajo de prueba</button><button onClick={() => { setNotice("Logs de API abiertos más abajo."); document.getElementById("api-logs-panel")?.scrollIntoView({ behavior: "smooth", block: "start" }); }} className="border border-[var(--line)] text-sm font-bold px-4 py-2.5 rounded-full hover:bg-white/5 transition flex items-center gap-1.5"><Terminal size={15} /> Ver logs</button></div>
              </div>

              <div id="api-logs-panel" className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="font-bold flex items-center gap-2"><Terminal size={18} className="text-[#55e3dc]" /> Logs de API</h2><button onClick={() => { setApiLogs([]); setNotice("Logs limpiados."); }} className="text-xs font-bold px-3 py-2 rounded-full border border-white/15 hover:bg-white/10 transition flex items-center gap-1.5"><Trash2 size={13} /> Limpiar logs</button></div>
                <div className="mt-4 bg-[#05070f] border border-white/10 rounded-xl p-3.5 min-h-[120px] max-h-[240px] overflow-y-auto font-mono text-[12px] leading-relaxed">{apiLogs.length === 0 ? <p className="text-[var(--muted)]">Sin registros. Crea un trabajo o prueba la conexión para ver actividad.</p> : apiLogs.map((line, i) => (<p key={i} className="text-emerald-100/90 break-words">{line}</p>))}</div>
              </div>

              <div className="glass rounded-2xl p-4 sm:p-5 neon-border">
                <h2 className="font-bold flex items-center gap-2"><CreditCard size={18} className="text-[#ff5ea8]" /> Webhooks Stripe</h2>
                <p className="text-xs text-[var(--muted)] mt-1">Cuando Stripe confirma un pago, el webhook suma los créditos a tu cuenta.</p>
                <div className="mt-4 flex flex-wrap items-center gap-3 bg-black/25 border border-white/10 rounded-xl p-3.5"><span className="w-10 h-10 rounded-full bg-[#ff5ea8]/20 grid place-items-center shrink-0"><CreditCard size={18} className="text-[#ff5ea8]" /></span><div className="min-w-0 flex-1"><p className="text-sm font-bold">Pago 12€ - 10 créditos - Usuario demo@ejemplo.com</p><p className="text-xs text-[var(--muted)] mt-0.5">Ejemplo de webhook: pago confirmado → créditos sumados. Saldo actual: <b className="text-white">{credits.toLocaleString("es-ES")} créditos</b>.</p></div><button onClick={simulateStripeWebhook} className="bg-white text-black text-sm font-bold px-4 py-2.5 rounded-full hover:bg-white/90 transition shrink-0">Simular webhook</button></div>
              </div>
            </div>
          </section>
        )}

        {tab === "exportar" && (
          <section className="max-w-[900px] mx-auto">
            <p className="text-xs tracking-widest text-[var(--muted)]">EXPORTAR</p><h1 className="text-[clamp(28px,5vw,40px)] font-bold mt-1 mb-1 leading-none">Tus clips generados</h1><p className="text-sm text-[var(--muted)] mb-4">Aquí se guardan los clips que generas. Vuelve a abrir uno para revisar su prompt y su cámara.</p>
            {clips.length === 0 ? <div className="glass border-dashed border-[var(--line)] rounded-2xl p-8 text-center"><Download size={28} className="mx-auto text-[var(--muted)]" /><p className="font-bold mt-3">Aún no hay clips para exportar.</p><p className="text-sm text-[var(--muted)] mt-1">Genera tu primer clip y aparecerá aquí.</p><button onClick={() => setTab("generar")} className="mt-4 bg-[var(--purple)] text-white text-sm font-bold px-4 py-2.5 rounded-full">Ir a Generar</button></div> : <div className="space-y-3">{clips.map((cl) => (<div key={cl.id} className="glass rounded-2xl p-4"><p className="font-bold">{(cl.value?.moves || []).join(" + ") || "Clip"}</p><p className="text-sm text-[var(--muted)] mt-1 line-clamp-2">{cl.value?.prompt}</p><p className="text-xs text-[var(--muted-2)] mt-2">{cl.value?.provider} · {cl.value?.format} · {cl.value?.duration} · {cl.value?.createdLabel}</p><button onClick={() => { setPrompt(cl.value?.prompt || ""); setSelectedMoves(cl.value?.moves || []); setTab("generar"); setNotice("Clip cargado en el generador."); }} className="mt-3 text-sm font-bold bg-white text-black px-4 py-2 rounded-full">Abrir en Generar</button></div>))}</div>}
          </section>
        )}

        <footer className="mt-6 flex flex-wrap gap-2 items-center justify-between text-[11px] text-[var(--muted)] border-t border-[var(--line)] pt-4 pb-2">
          <span className="flex items-center gap-1.5"><Lock size={12} className="text-emerald-300" /> Contenido protegido por licencia BOOK2CINEMA. Copia no autorizada detectada por ID invisible.</span>
          <span className="flex gap-3"><span className="flex items-center gap-1"><Download size={12} /> Exportar</span><span>AI STUDIO V4 PRO · Herramienta genérica</span></span>
        </footer>
      </main>
    </div>
  );
}
